# Verificación · Hogar Playa 1.1.1

Fecha: 26/10/2026. APK de entrega: cu.hogarplaya, versión 1.1.1, código 3, Android mínimo 8 (API 26), objetivo API 35.

SHA-256: `a5751e32b47cfa4800453acacbe8da4f27503ccbcb7136fbca45fba729662719`

Comprobaciones de esta actualización:

- Cliente HTTP real compilado y probado con conexiones simuladas: 401, 403, redirección a inicio de sesión, HTML sin JSON, error temporal 500, restricciones de URL y redirección segura GET a Googleusercontent. El mensaje explica la configuración y la prueba en incógnito; no muestra la credencial.
- API móvil, protección USD, creador y cuentas: suites JavaScript correctas con servicios Google simulados.
- Interfaz móvil en Chromium: flujo de perfiles y compras, ayuda 401/403, estado de error sin indicar conexión correcta, ausencia de modificaciones de movimientos al abrir la ayuda y pantalla sin desbordamientos.
- Firma APK v2/v3 verificada. El certificado coincide con la versión 1.1.0; permite instalar encima y conservar los datos. Los esquemas SQLite y los formatos de movimientos no cambian.
- Script completo regenerado: 1,494 líneas y 92 funciones; incluye la ayuda en Guía, paso 28, y conserva FIN_DEL_CODIGO.

Las comprobaciones previas de la versión 1.1.0 cubrieron 23 casos financieros recalculados, diez suites JavaScript y la instrumentación en Android 10: SQLite, PIN, trazabilidad, reintentos sin duplicados, compras sin red, envío automático al volver internet y avisos del plan CUP. No se repitió toda la instrumentación del emulador para este cambio de mensajes y ayuda.

La implementación y autorización en la cuenta Google real pertenecen al propietario. La consulta anónima a su URL quedó bloqueada por la red de este entorno antes de llegar a Google; no se verificaron sus permisos ni se escribió en su hoja. La actualización explica cómo corregir el acceso; no puede cambiar esos permisos desde el teléfono.
