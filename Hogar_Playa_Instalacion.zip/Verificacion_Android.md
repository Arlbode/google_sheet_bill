# Verificación · Hogar Playa 1.2.0

Fecha: 27/10/2026. APK cu.hogarplaya, versión 1.2.0, código 4, Android mínimo 8 (API 26), objetivo API 35.

SHA-256: `fba90170e38417011ca0301db2da3e1811e7b23eb14e6f434352c54ca7df8fa6`

- Firma APK v2/v3 verificada; mismo certificado que 1.1.0 y 1.1.1. Instalación sobre la anterior con migración aditiva de SQLite 1 a 2. No se recrean perfiles ni operaciones.
- Emulador Android 10: actualización desde la versión 1.1.0 y conservación de perfiles, jornada y límite; dos compradores, mediana de 15 días con tres fechas, aviso mensual previo, repetición confirmada, compra y marca en una transacción, rechazo al superar el límite, doble toque sin duplicados, persistencia tras cerrar el proceso y traslado de la cesta sin registrar gastos.
- Integración nativa con la API real del proyecto ejecutada sobre servicios Google simulados: PIN, cestas, salario, cambio, compras, ahorro, pérdida de respuesta y reintentos, plan CUP, notificación nativa, compras del modo con tope, ingreso en transferencia, saldos separados y estadísticas del producto después de sincronizar. Todos los escenarios ejecutados pasaron.
- 11 suites JavaScript verificadas: cuentas, creador, menú, gasto, formularios de dinero, automatización, precios, API móvil, protección USD, compras/CUP e interfaz. Prueba Java del transporte HTTP correcta.
- 3 casos financieros nuevos recalculados en LibreOffice con las fórmulas reales del desglose: mezcla de ingresos/gastos/cambios por formato, periodo anterior al inicio y reparto inicial inválido. Total CUP = efectivo + transferencia.
- Chromium móvil: formato de ingreso CUP y proyección bancaria, productos mensuales ocultos y visibles, aviso antes de repetir, unidades y precio que se vacía al cambiar la unidad, cálculo cantidad por precio, confirmación y lista tachada, tope, logotipo a Inicio y respuesta de error visible con viewport reducido a 360 × 400.
- El script completo incluye los 8 módulos .gs, 1,594 líneas y 96 funciones. Conserva FIN_DEL_CODIGO y Guía con los pasos 29 a 32 para estas novedades.

Los 23 casos financieros anteriores del libro Excel se habían verificado en la entrega anterior; no se regeneró el libro histórico durante esta actualización. Las pruebas del desglose nuevo utilizaron libros temporales sin modificar el Excel ni la hoja personal.

La conexión de Google real sigue dependiendo de la autorización y la implementación del propietario. Ninguna prueba escribió en su Sheet ni incorporó datos financieros reales al paquete. Los precios iniciales conservan su fecha de referencia; no se presentan como nuevas cotizaciones del 27/10. El historial y las capturas de pruebas son ficticios.

La adaptación nativa de insets incluye Android 11+ y el diseño de Android 15; la ejecución del emulador se verificó en Android 10, no en todos los modelos. El tope se aplica por fecha y teléfono; no puede controlar pagos físicos ni conocer compras offline de otro teléfono. Las tareas en segundo plano dependen de Android y de la red.
