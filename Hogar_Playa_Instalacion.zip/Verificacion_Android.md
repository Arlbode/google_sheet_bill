# Verificación · Hogar Playa 1.1.0

Fecha: 26/10/2026. APK de entrega: cu.hogarplaya, versión 1.1.0, código 2, Android mínimo 8 (API 26), objetivo API 35. Firma APK v2/v3 verificada.

SHA-256: `ede227016bc1800b93ee6c8e9e9a3297f0c935043e64870e479c8d0c11ebc5c4`

- 23 pruebas financieras recalculadas en LibreOffice: correctas.
- 10 suites JavaScript: cuentas, creador, formularios, menú, automatización, precios, API móvil, protección USD e interfaz: correctas.
- Emulador Android 10 (API 29): dos perfiles con PIN, cinco movimientos, cesta atómica, persistencia tras cerrar proceso y coma decimal: correctos.
- API de Google simulada ejecutando el mismo código: salario, cambio, compra, ahorro, credencial cifrada, pérdida de respuesta y reintento sin duplicados: correctos.
- Registro sin red con teléfono ya vinculado, recuperación del pendiente tras cerrar y envío automático por JobScheduler al recuperar red: correctos. Se comprobó también una conexión sin la marca VALIDATED de Android.
- Cálculo local de reserva USD, ingreso CUP pendiente, pago vinculado y notificación nativa con referencia y vigencia: correctos.
- La APK de entrega se instaló y abrió en el emulador; se comprobó la pantalla inicial para crear el perfil. No incorpora clases ni perfiles de prueba.
- El script completo contiene las fuentes de todos los módulos, 1.494 líneas y 92 funciones. Conserva el cierre FIN_DEL_CODIGO.

La implementación y autorización en la cuenta Google real del usuario quedan a cargo del propietario. Ninguna prueba escribió en su Sheet. Las capturas del navegador utilizan datos de prueba. La ejecución en segundo plano y los avisos están sujetos a las restricciones de batería, red y permisos de Android.
