# Verificación · Hogar Playa 1.2.2

Fecha: 27/10/2026. APK cu.hogarplaya, versión 1.2.2, código 6. Android mínimo 8 (API 26), objetivo API 35. Firma v2/v3 válida, mismo certificado de las versiones anteriores.

SHA-256: `ce8df53ab53d90895fd40a485c5522dea80f1c0014ff3f24ebb3352a87d44e85`

Comprobaciones de esta entrega:

- 13 suites JavaScript correctas, incluida la nueva gestión de planes y la interfaz en Chromium. Se conservan las comprobaciones de cuentas, creador, menú, formularios, precios, automatización, API, protección USD, compras/CUP y oferta Yosvany.
- Gestión de Plan CUP: alta, edición, cancelación y reactivación, previsto/pagado/pendiente, fecha futura, categoría, prioridad y notas. Crear o modificar planes no añade movimientos de dinero. Los pagos parciales conservan su vínculo; cancelar no devuelve dinero. Un pago real ya vinculado puede llegar después de una cancelación sin perder su trazabilidad.
- Conflictos de versión: se rechaza una edición basada en una versión anterior sin sobrescribir la nueva. Se protege la categoría cuando hay gastos asociados y se impide reducir el importe por debajo de lo pagado. Se conservan textos que empiezan por caracteres de fórmula como texto seguro.
- Reintentos: respuesta repetida no duplica planes ni recibos; interrupción entre escritura del plan y recibo se recupera, incluso si llega otro cambio antes del reintento original. API 3 requiere la hoja preparada; un servidor anterior no puede ignorar silenciosamente la cola de planes.
- Emulador Android 10: SQLite 3 conserva los perfiles de la instalación anterior. Los planes se crean, editan, cancelan y reactivan offline en una cola separada de los gastos. Se conserva el UUID al cerrar el proceso. Un pago parcial local descuenta el pendiente. Las solicitudes intentadas se congelan hasta recibir confirmación, y los pagos dependientes esperan a que exista el plan. Se prueba la corrección de un rechazo y se impide abandonar un plan nuevo dejando su pago sin destino.
- Sincronización nativa contra servicios Google simulados: alta de plan de 4000 CUP, ingreso de 5000 CUP por transferencia y gasto vinculado de 1000 CUP; pérdida de respuesta y reintento sin duplicados. El resultado es 3000 CUP pendientes en el plan y 4000 CUP en transferencia. Cancelarlo conserva ese saldo y los dos movimientos.
- Interfaz: consultar, crear, editar, cancelar/reactivar, filtros, importe pendiente, categoría bloqueada con pagos y acceso a Registrar pago con vínculo automático. Filtros compactos y pantalla sin desbordamientos. El PIN conserva su valor y foco ante actualizaciones en segundo plano.
- Ingreso unificado: el acceso separado de ingreso CUP desaparece. Seleccionar CUP muestra Efectivo/Transferencia en + Ingreso y en Registrar movimiento → Ingreso; seleccionar USD lo oculta. Falta de formato CUP impide guardar. El formulario del Sheet también oculta el formato en USD.
- Regresión de lista múltiple, total de pendientes, tope diario, aviso de repetición mensual y notificación de prueba. El catálogo mantiene 88 productos y las 56 referencias Yosvany, sin inventar unidades de envasados.
- El script consolidado contiene 1721 líneas, todos los módulos .gs y el cierre FIN_DEL_CODIGO. Añade Planes app y Plan CUP L:Q sin borrar registros. Guía incorpora los pasos 38 y 39. La APK de entrega no contiene pruebas nativas ni un servidor de pruebas.

Las pruebas de Apps Script y la sincronización usan servicios Google simulados; no se modificó el Sheet real del usuario. La ejecución de iniciarHogar y la actualización de la implementación requieren la cuenta propietaria. Las pruebas móviles usan un paquete separado y datos ficticios. No se regeneró el Excel histórico. Se mantiene la cobertura anterior de fórmulas recalculadas y del transporte HTTPS; esta entrega no cambia las fórmulas de saldos ni el motor HTTP.

El tope diario sigue siendo por teléfono y fecha. Android puede retrasar los trabajos de fondo. Sin internet, la app conoce la última copia del Sheet y sus cambios locales; los cambios de otros teléfonos llegan al sincronizar.
