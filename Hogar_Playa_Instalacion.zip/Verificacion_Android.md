# Verificación · Hogar Playa 1.2.1

Fecha: 27/10/2026. APK cu.hogarplaya, versión 1.2.1, código 5. Android mínimo 8 (API 26), objetivo API 35. Firma v2/v3 válida, mismo certificado de las versiones previas.

SHA-256: `7a15f5ac75efcc56befb76cf2a9647b7f1f403af24ab6a23cf604fad7d658953`

Comprobaciones de esta entrega:

- Regresión del PIN en Chromium: escribir un PIN parcial, recibir una actualización en segundo plano y conservar formulario, valor y foco. Una sesión que se bloquea sigue cerrando formularios financieros.
- Selección múltiple: elegir dos productos, revisar un formulario, guardar juntos sin gastos y conservar un borrador sin precio para completarlo después.
- Emulador Android 10: lote inválido revierte todas las filas; lote válido admite borradores y reintentos sin duplicados. Confirmar una presentación incompleta no genera gastos. La notificación 7102 PRUEBA se entrega sin modificar operaciones, copia financiera, plan ni huella del aviso real.
- Tarjeta del tope: suma todos los pendientes; convierte 2 lb a 150 CUP con tasa fija 870 a 0,34 USD para el tope. Disponible estimado = tope − comprado − lista. Ejemplo de UI: tope 10 USD y lista 6 dejan 4; confirmar la compra mantiene 4, sin doble descuento. Lista 11 con 6 comprados deja −7 y señala los precios faltantes.
- 12 suites JavaScript correctas: cuentas, creador, menú, formulario de gastos, formularios de dinero, precios, automatización, API, protección USD, compras/CUP, oferta Yosvany e interfaz. Prueba de transporte HTTP correcta.
- 4 casos financieros recalculados en LibreOffice: 3 del desglose CUP y 1 de la nueva oferta, con múltiples aserciones. Arroz por libra calculado; un litro de aceite requiere dos botellas de 900 ml; unidades sin confirmar no se presupuestan como si fueran conocidas.
- Oferta Yosvany: 56 importes conservados, 41 productos nuevos, 88 en catálogo. 19 presentaciones de envasados pendientes. Se identifican como información facilitada por el usuario, en CUP/libra para granel, sin atribuirla a webs ni inventar dirección/contacto. Directorio y Actualizaciones reciben trazabilidad.
- Importación probada sobre un catálogo anterior: conserva Registro, Cambios, saldos iniciales, tasa, productos propios, cantidades con unidad compatible y fórmula del boniato semanal de los perros. Convierte kg a lb; unidades sin equivalencia conservan el valor anterior en observaciones y exigen revisión. Repetir no reimporta ni borra correcciones posteriores.
- La APK contiene el catálogo de 88 productos y los assets actuales. El script consolidado contiene 1,657 líneas, todos los módulos .gs y el cierre FIN_DEL_CODIGO.

Las pruebas de Apps Script usan servicios Google simulados. La autorización, ejecución de iniciarHogar y actualización de la implementación se realizan desde la cuenta propietaria; no se modificó su Sheet real desde este entorno. Las pruebas y capturas usan datos ficticios. La oferta local no equivale a una nueva consulta de todas las fuentes web. El Excel histórico no se regeneró; esta entrega actualiza Google Sheets y Android.

Las comprobaciones anteriores de Android cubren perfil/PIN, SQLite, gastos offline, reintentos sin duplicados, notificación del plan, protección USD y sincronización. El tope permanece por jornada y teléfono. Android controla la ejecución en segundo plano y puede retrasar los avisos; PRUEBA comprueba la entrega, sin crear una necesidad de cambio ni ejecutar una operación financiera.
