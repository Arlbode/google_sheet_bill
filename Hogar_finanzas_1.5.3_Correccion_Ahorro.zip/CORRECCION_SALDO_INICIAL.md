# Corrección del saldo inicial reservado · compatible con APK 1.5.3

El ahorro inicial y los fondos iniciales ya declarados deben formar parte de la cuenta USD. La 1.5.3 los restaba de la disponibilidad sin incorporarlos al saldo cuando Cuentas B6 seguía en cero.

La corrección integra automáticamente Ajustes B13 y Fondos B6:B11 cuando Cuentas B6 vale cero. Si B6 contiene un total no nulo, se conserva como total inicial completo: las reservas no se suman de nuevo. Los aportes del periodo se mantienen como reservas y nunca se convierten en ingresos.

La fórmula de Cuentas F6 y el cálculo que recibe Android aplican la misma regla. B6, B13 y los saldos de Fondos permanecen intactos. Las modificaciones futuras del ahorro inicial se reflejan por fórmula cuando B6 está a cero. Un total manual no nulo menor que las reservas no se aumenta automáticamente; debe revisarse como una discrepancia de datos.

## Aplicación en la hoja existente

1. Abre Extensiones → Apps Script en la hoja habitual.
2. Sustituye el contenido de Código.gs por **Script_Completo_Hogar_1.5.3_Correccion_Ahorro.txt** y guarda.
3. Ejecuta **integrarSaldosInicialesReservados** una vez. Actualiza solo la fórmula conocida de Cuentas F6 y sus notas explicativas. Si detecta una fórmula propia, la conserva y pide revisión. Ejecutarlo otra vez no vuelve a sumar dinero.
4. En Implementar → Gestionar implementaciones, edita la implementación existente y elige Nueva versión. Conserva la misma URL /exec.
5. Pulsa **Sincronizar** en la app.

La APK 1.5.3 sigue siendo válida. Se conserva la vinculación del teléfono, los perfiles y los movimientos; no hace falta generar otro código Android. Esta corrección reemplaza el backend incluido en el paquete original 1.5.3.

## Alcance y validación

La corrección solo integra reservas iniciales USD ya declaradas. Los importes y formatos de operaciones CUP se conservan para que cualquier discrepancia real siga visible.

Se prueba el cálculo real del backend, la fórmula recalculada con LibreOffice, la repetibilidad, la conservación de entradas y la ausencia de doble suma cuando el saldo manual ya incluye reservas. También se contrasta localmente con la copia financiera facilitada por el usuario. Esa copia y sus datos no se incluyen en este paquete ni en las pruebas públicas.

Preparar estos archivos no despliega Apps Script ni publica cambios en GitHub o en el entorno. La hoja original no se ha modificado desde esta sesión.
