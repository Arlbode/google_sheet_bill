# Hogar finanzas 1.5.3 · fondos y ahorros

Base exacta: `5fa64919cacaeab499c5e2b21318c7729ceb7e41`, última 1.5.2 publicada. Paquete conservado: `cu.hogarplaya.recuperada`; versionCode 13 / versionName 1.5.3. La APK 1.5.2 y la base `Hogar_Playa.apk` permanecen intactas.

## Cambios

- Aportes a cada fondo y al ahorro en USD, CUP efectivo o CUP transferencia. No crean ingresos ni cambian el saldo físico: reservan parte de él.
- Selección «Pagar desde» en Registrar gasto, al confirmar el carrito y al confirmar un producto de Modo compra. La categoría del gasto se conserva para Plan CUP; `fundCategory` indica qué fondo lo financia. El carrito completo usa el fondo seleccionado y comprueba todos sus grupos antes de confirmar la transacción.
- Un pago de fondo descuenta una vez la moneda y formato utilizados, reduce ese fondo y queda excluido de Consumo. El fondo necesita saldo en esa moneda/formato: no convierte USD a CUP automáticamente.
- Inicio muestra dinero libre por moneda/formato, excluyendo fondos y ahorro. Disponible para Consumo es el menor entre el margen mensual y el equivalente del saldo libre; los equivalentes usan la referencia visible y son orientativos. La partida presupuestaria sigue visible por separado.
- Fondos y ahorro muestra balances e historial acumulados, con filtro por reserva, incluyendo saldos iniciales y meses anteriores. No usa el límite de 250 del historial general: el backend entrega un ledger completo de las reservas del periodo de control. Las operaciones rechazadas quedan excluidas; los UUID conocidos evitan duplicar pendientes ya recibidos.
- Retiro ahorro libera dinero de la reserva, sin crear ingreso. Los pagos antiguos con categoría de fondo mantienen su significado aunque no tengan el nuevo campo.
- Plan CUP continúa conciliándose desde el mismo gasto y su `planId`. Anotar un plan no crea un descuento. El cálculo de cambio excluye CUP reservados y protege los fondos USD, solapando la protección de ahorro con el ahorro ya separado para no descontarlo dos veces.
- PIN diario, ubicación optativa, UUID, colas y cierre/historial de Modo compra se conservan. La base SQLite y sus tablas existentes no se recrean. La extensión se compila desde `native-src`, nunca desde el Java decompilado.

## Backend y actualización

El script completo está en [Script_Completo_Hogar_1.5.3.txt](Script_Completo_Hogar_1.5.3.txt), idéntico a `recovered-source/backend/Code.gs` y a la copia actual `Script_Completo_Hogar_Tasa_CUP.txt`.

1. Conserva la hoja y la app instaladas. Sincroniza los dos teléfonos antes de actualizar.
2. Sustituye el código de Apps Script por el script completo 1.5.3 y ejecuta `iniciarHogar` en la misma hoja. Añade `Registro!AE` («Fondo de pago»), sin reescribir los movimientos, sus UUID, fechas, saldos iniciales ni perfiles. Si AE ya contiene otros datos, la preparación se detiene para que los conserves antes de continuar.
3. Publica una nueva versión de la implementación existente conservando la URL `/exec`. No vuelvas a vincular el hogar ni crees perfiles nuevos.
4. Instala la APK firmada 1.5.3 encima de la app actual, sin desinstalar ni borrar datos, y sincroniza. El teléfono exige el snapshot actualizado antes de pagar fondos de un hogar vinculado.

Las fórmulas de Consumo y Fondos de la plantilla incorporan el campo de financiación. La migración es repetible y solo sustituye fórmulas reconocidas; conserva fórmulas propias. Los balances detallados de reservas se calculan desde los importes originales, no desde equivalentes a una tasa nueva. Los movimientos del Sheet que estén fuera del periodo de control o no tengan estado OK no se incorporan al ledger.

## Validación y límites

- Compilación completa de recursos y extensión Android con SDK 35. Identidad y versión comprobadas con aapt2; zipalign correcto. El verificador DEX confirma que todos los métodos originales permanecen idénticos, salvo `MainActivity$Bridge.call`, la entrada autorizada.
- 16 pruebas Python de recuperación, firma, respaldos y fórmulas. LibreOffice recalcula también las fórmulas migradas: los pagos de fondo antiguos y nuevos reducen el fondo y la cuenta física una vez, sin sumarse a Consumo.
- 29 casos JavaScript de tasas, ledger completo, saldos por moneda/formato, protección y Plan CUP, UUID y reintentos. Se ejecutan los archivos directamente con Node para verificar sus casos individuales.
- Pruebas Chromium de Inicio/tasas, sesión diaria, historial/cierre de compras, teclado/carrito y nuevos selectores de fondo en las tres rutas. El puente de estas pruebas de interfaz es simulado.
- No se ha probado la instalación/actualización en Android ni la sincronización con la hoja privada en esta sesión. No hay emulador disponible. Las pruebas del backend usan datos ficticios.

La compilación `CHECK_ONLY_Hogar_finanzas_1.5.3.apk` es interna, sin firma y **no instalable como actualización**. No se entrega como release firmada.

## Firma restaurada y verificada

Se restauró el ZIP aportado por el usuario con el procedimiento existente. La clave privada y contraseña quedan fuera del checkout, con permisos privados. No se generó otra clave ni se modificó la identidad.

La APK 1.5.3 está firmada con el mismo certificado que la 1.5.2:

`7374684814395e3df3e4a41b6d0d20a739dddba331a828d0f72d5d37ea78e6c1`

`apksigner verify --verbose --print-certs` confirma las firmas v2 y v3; zipalign y la comprobación del paquete/versionCode/versionName son correctos. Los recursos y assets son idénticos al paquete de comprobación previo. El DEX reconstruido tiene una organización binaria distinta, pero el desensamblado completo de ambas compilaciones es idéntico, clase por clase. El constructor también confirma la conservación de los métodos originales fuera de la entrada autorizada del puente.

Descarga `Hogar_finanzas_1.5.3.apk` y su `.sha256`, o `Hogar_finanzas_1.5.3_Instalacion.zip`, que incluye APK, script completo e instrucciones. Los paquetes públicos no contienen el ZIP privado, el PKCS12 ni contraseñas. La instalación en dispositivo y la sincronización con el Sheet privado siguen sin probarse en esta sesión.

La entrega de archivos no publica el entorno, GitHub ni el backend. Para futuras restauraciones sigue [RESPALDO_Y_RECUPERACION_FIRMA.md](RESPALDO_Y_RECUPERACION_FIRMA.md).
